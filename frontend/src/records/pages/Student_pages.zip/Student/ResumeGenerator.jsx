 import React, { useState, useEffect } from "react";
import { Search, RotateCcw, FileText, Download, Eye, Filter, ChevronDown, Calendar, X } from "lucide-react";
import { useUser } from "../../contexts/UserContext";
import axios from "axios";

const EnhancedResumeGenerator = () => {
  const { user } = useUser();

  // State management
  const [selectedSections, setSelectedSections] = useState({
    "Student Details": true,
    "Education": true,
    "Events Attended": false,
    "Events Organized": false,
    "Online Courses": false,
    "Achievements": true,
    "Internships": true,
    "Scholarships": false,
    "Hackathon Event Details": false,
    "Extracurricular Details": false,
    "Project Details": true,
    "Competency Coding Details": true,
    "Student Publication Details": false,
    "Student Non-CGPA Details": false,
  });

  const [dateFilters, setDateFilters] = useState({
    startDate: "",
    endDate: "",
    month: "",
    year: ""
  });

  const [studentData, setStudentData] = useState({});
  const [filteredData, setFilteredData] = useState({});
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [previewMode, setPreviewMode] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const [profileImageData, setProfileImageData] = useState(null);

  // Activity list
  const activityList = [
    { name: 'Student Details', icon: '👤', color: 'blue' },
    { name: 'Education', icon: '🎓', color: 'emerald' },
    { name: 'Events Attended', icon: '📅', color: 'green' },
    { name: 'Events Organized', icon: '🎯', color: 'purple' },
    { name: 'Online Courses', icon: '📚', color: 'indigo' },
    { name: 'Achievements', icon: '🏆', color: 'yellow' },
    { name: 'Internships', icon: '💼', color: 'pink' },
    { name: 'Scholarships', icon: '💰', color: 'cyan' },
    { name: 'Hackathon Event Details', icon: '💻', color: 'orange' },
    { name: 'Extracurricular Details', icon: '🎨', color: 'teal' },
    { name: 'Project Details', icon: '🚀', color: 'red' },
    { name: 'Competency Coding Details', icon: '⚡', color: 'violet' },
    { name: 'Student Publication Details', icon: '📝', color: 'emerald' },
    { name: 'Student Non-CGPA Details', icon: '📊', color: 'amber' },
  ];

  const months = [
    { value: "01", label: "January" },
    { value: "02", label: "February" },
    { value: "03", label: "March" },
    { value: "04", label: "April" },
    { value: "05", label: "May" },
    { value: "06", label: "June" },
    { value: "07", label: "July" },
    { value: "08", label: "August" },
    { value: "09", label: "September" },
    { value: "10", label: "October" },
    { value: "11", label: "November" },
    { value: "12", label: "December" }
  ];

  const currentYear = new Date().getFullYear();
  const years = Array.from({ length: 10 }, (_, i) => currentYear - i);

  // Get user from localStorage
  const getUserData = () => {
    try {
      const userStr = localStorage.getItem("user");
      if (!userStr) {
        throw new Error("No user data found. Please login again.");
      }
      const user = JSON.parse(userStr);
      if (!user.Userid) {
        throw new Error("Invalid user data. Please login again.");
      }
      return user;
    } catch (err) {
      console.error("Error parsing user data:", err);
      throw err;
    }
  };

  // Fetch staff data from API
  useEffect(() => {
    const fetchStudentData = async () => {
      if (!user?.Userid) return;

      try {
        setLoading(true);
        setError(null);

        const token = localStorage.getItem('token');
        const response = await axios.get(
          `http://localhost:4000/api/resume/student-data/${user.Userid}`,
          {
            headers: {
              Authorization: `Bearer ${token}`
            }
          }
        );

        if (response.data.success) {
          const apiData = response.data.data;

          // Clean phone and address to remove corrupted characters and non-printable text
          const cleanPhone = (apiData.userInfo?.phone || "")
            .replace(/[^\x20-\x7E]/g, "") // Remove non-printable ASCII characters
            .replace(/[^\d\s\-\+\(\)]/g, "") // Remove non-numeric characters except common phone symbols
            .trim();
          const cleanAddress = (apiData.userInfo?.address || "")
            .replace(/[^\x20-\x7E]/g, "") // Remove non-printable ASCII characters
            .replace(/[^\w\s,.-]/g, "") // Remove special characters but keep common address symbols
            .trim();

          // Transform API data to match component expectations
          const transformedData = {
            "Student Details": apiData["Student Details"] || [],
            "Education": apiData["Education"] || [],
            "Events Attended": apiData["Events Attended"] || [],
            "Events Organized": apiData["Events Organized"] || [],
            "Online Courses": apiData["Online Courses"] || [],
            "Achievements": apiData["Achievements"] || [],
            "Internships": apiData["Internships"] || [],
            "Scholarships": apiData["Scholarships"] || [],
            "Hackathon Event Details": apiData["Hackathon Event Details"] || [],
            "Extracurricular Details": apiData["Extracurricular Details"] || [],
            "Project Details": apiData["Project Details"] || [],
            "Competency Coding Details": apiData["Competency Coding Details"] || [],
            "Student Publication Details": apiData["Student Publication Details"] || [],
            "Student Non-CGPA Details": apiData["Student Non-CGPA Details"] || [],
            userInfo: {
              ...apiData.userInfo,
              phone: cleanPhone,
              address: cleanAddress,
              name: apiData.userInfo?.name || user.username || 'N/A',
              email: apiData.userInfo?.email || user.email || 'N/A',
              regno: apiData.userInfo?.regno || user.regno || 'N/A',
              department: apiData.userInfo?.department || 'N/A',
              batch: apiData.userInfo?.batch || 'N/A'
            }
          };

          setStudentData(transformedData);
          setFilteredData(transformedData);

          // Fetch profile image from user table
          const profileImage = transformedData.userInfo?.profile_image;
          if (profileImage) {
            try {
const imageResponse = await axios.get(`http://localhost:4000/api/resume/profile-image/${user.Userid}`, {
                headers: {
                  Authorization: `Bearer ${localStorage.getItem('token')}`
                }
              });
              if (imageResponse.data.success) {
                setProfileImageData({
                  data: imageResponse.data.imageData,
                  format: imageResponse.data.format
                });
              }
            } catch (imageErr) {
              console.warn('Could not fetch profile image:', imageErr);
            }
          }
        } else {
          throw new Error(response.data.error || 'Failed to fetch data');
        }
      } catch (err) {
        console.error('Error fetching student data:', err);
        setError(err.response?.data?.error || err.message || 'Failed to load student data');

        // Fallback to basic user info if API fails
        const fallbackData = {
          "Student Details": [],
          "Education": [],
          "Events Attended": [],
          "Events Organized": [],
          "Online Courses": [],
          "Achievements": [],
          "Internships": [],
          "Scholarships": [],
          "Hackathon Event Details": [],
          "Extracurricular Details": [],
          "Project Details": [],
          "Competency Coding Details": [],
          "Student Publication Details": [],
          "Student Non-CGPA Details": [],
          userInfo: {
            name: user.username || 'N/A',
            email: user.email || 'N/A',
            phone: 'N/A',
            regno: user.regno || 'N/A',
            department: 'N/A',
            batch: 'N/A',
            address: 'N/A'
          }
        };

        setStudentData(fallbackData);
        setFilteredData(fallbackData);
      } finally {
        setLoading(false);
      }
    };

    fetchStudentData();
  }, [user]);

  // Filter data by date
  const filterByDate = (data, dateField = 'date_awarded') => {
    if (!dateFilters.startDate && !dateFilters.endDate && !dateFilters.month && !dateFilters.year) {
      return data;
    }

    return data.filter(item => {
      let itemDate = item[dateField] || item.from_date || item.start_date || item.date || item.appliedDate;
      if (!itemDate) return false;

      const date = new Date(itemDate);
      const itemYear = date.getFullYear().toString();
      const itemMonth = (date.getMonth() + 1).toString().padStart(2, '0');

      if (dateFilters.year && itemYear !== dateFilters.year) return false;
      if (dateFilters.month && itemMonth !== dateFilters.month) return false;
      if (dateFilters.startDate && date < new Date(dateFilters.startDate)) return false;
      if (dateFilters.endDate && date > new Date(dateFilters.endDate)) return false;

      return true;
    });
  };

  const applyFilters = () => {
    const filtered = {};
    
    Object.keys(studentData).forEach(key => {
      if (key === 'userInfo') {
        filtered[key] = studentData[key];
      } else if (Array.isArray(studentData[key])) {
        filtered[key] = filterByDate(studentData[key]);
      } else {
        filtered[key] = studentData[key];
      }
    });

    setFilteredData(filtered);
  };

  const resetFilters = () => {
    setDateFilters({ startDate: "", endDate: "", month: "", year: "" });
    setSelectedSections({
      "Student Details": true,
      "Events Attended": false,
      "Events Organized": false,
      "Online Courses": false,
      "Achievements": false,
      "Internships": false,
      "Scholarships": false,
      "Hackathon Event Details": false,
      "Extracurricular Details": false,
      "Project Details": false,
      "Competency Coding Details": false,
      "Student Publication Details": false,
      "Student Non-CGPA Details": false,
    });
    setFilteredData(studentData);
  };

  const toggleSection = (section) => {
    if (section === "Student Details") return;
    setSelectedSections((prev) => ({ ...prev, [section]: !prev[section] }));
  };

  const generatePDF = async (isPreview = false) => {
    try {
      // Import jsPDF dynamically
      const { jsPDF } = await import('jspdf');

      const doc = new jsPDF();
      const { userInfo } = filteredData;

      if (!userInfo) {
        alert('User information not available. Please try again.');
        return;
      }

      const pageWidth = doc.internal.pageSize.getWidth();
      const pageHeight = doc.internal.pageSize.getHeight();

      // Define layout constants
      const leftColumnWidth = 65;
      const rightColumnStart = leftColumnWidth + 5;
      const margin = 10;

      // Left sidebar background (light gray)
      doc.setFillColor(230, 230, 230);
      doc.rect(0, 0, leftColumnWidth, pageHeight, 'F');

      // Vertical divider line
      doc.setDrawColor(100, 100, 100);
      doc.setLineWidth(0.5);
      doc.line(leftColumnWidth, 0, leftColumnWidth, pageHeight);

      let leftY = 20;
      let rightY = 20;

      // ===== LEFT COLUMN =====

      // Profile Picture
      if (profileImageData && profileImageData.data) {
        try {
          // Add the actual profile image from user table - square format
          doc.addImage(profileImageData.data, profileImageData.format, leftColumnWidth / 2 - 15, leftY, 30, 30);
          // Draw square border around the image
          doc.setDrawColor(150, 150, 150);
          doc.setLineWidth(1);
          doc.rect(leftColumnWidth / 2 - 15, leftY, 30, 30);
        } catch (error) {
          console.warn('Could not add profile image to PDF:', error);
          // Fallback to placeholder
          doc.setFillColor(255, 255, 255);
          doc.rect(leftColumnWidth / 2 - 15, leftY, 30, 30, 'F');
          doc.setDrawColor(150, 150, 150);
          doc.setLineWidth(1);
          doc.rect(leftColumnWidth / 2 - 15, leftY, 30, 30);

          doc.setFontSize(20);
          doc.setTextColor(150, 150, 150);
          doc.text("👤", leftColumnWidth / 2, leftY + 18, { align: "center" });
        }
      } else {
        // Profile Picture Placeholder
        doc.setFillColor(255, 255, 255);
        doc.rect(leftColumnWidth / 2 - 15, leftY, 30, 30, 'F');
        doc.setDrawColor(150, 150, 150);
        doc.setLineWidth(1);
        doc.rect(leftColumnWidth / 2 - 15, leftY, 30, 30);

        // Add person icon placeholder
        doc.setFontSize(20);
        doc.setTextColor(150, 150, 150);
        doc.text("👤", leftColumnWidth / 2, leftY + 18, { align: "center" });
      }

      leftY += 40;

      // CONTACT Section
      doc.setFontSize(14);
      doc.setFont("helvetica", "bold");
      doc.setTextColor(0, 0, 0);
      doc.text("CONTACT", margin, leftY);

      // Underline
      doc.setLineWidth(0.5);
      doc.line(margin, leftY + 2, leftColumnWidth - margin, leftY + 2);
      leftY += 10;

      doc.setFontSize(9);
      doc.setFont("helvetica", "normal");

      // Email
      doc.text("✉", margin + 2, leftY);
      const emailLines = doc.splitTextToSize(userInfo?.email || "email@example.com", leftColumnWidth - margin - 10);
      doc.text(emailLines, margin + 8, leftY);
      leftY += emailLines.length * 5 + 3;

      // Phone
      doc.text("📞", margin + 2, leftY);
      doc.text(userInfo?.phone || "[Phone Number]", margin + 8, leftY);
      leftY += 10;

      // Address
      doc.text("📍", margin + 2, leftY);
      const addressLines = doc.splitTextToSize(userInfo?.address || "[Your Address]", leftColumnWidth - margin - 10);
      doc.text(addressLines, margin + 8, leftY);
      leftY += addressLines.length * 5 + 12;

      // EDUCATION Section
      doc.setFontSize(14);
      doc.setFont("helvetica", "bold");
      doc.text("EDUCATION", margin, leftY);
      doc.line(margin, leftY + 2, leftColumnWidth - margin, leftY + 2);
      leftY += 10;

      doc.setFontSize(8);
      doc.setFont("helvetica", "normal");

      const eduData = filteredData["Education"];
      if (Array.isArray(eduData) && eduData.length > 0) {
        const edu = eduData[0];

        // Degree
        if (edu.degree) {
          doc.setFont("helvetica", "bold");
          doc.text(edu.degree, margin, leftY);
          leftY += 5;
          doc.setFont("helvetica", "normal");
          doc.text(edu.institution || 'Institution', margin, leftY);
          leftY += 4;
          if (edu.grade_cgpa) {
            doc.setTextColor(100, 100, 100);
            doc.text(`Grade: ${edu.grade_cgpa} ${edu.grade_type || 'CGPA'}`, margin, leftY);
            leftY += 5;
            doc.setTextColor(0, 0, 0);
          }
          leftY += 3;
        }
      }

      leftY += 5;

      // SKILLS Section
      doc.setFontSize(14);
      doc.setFont("helvetica", "bold");
      doc.text("SKILLS", margin, leftY);
      doc.line(margin, leftY + 2, leftColumnWidth - margin, leftY + 2);
      leftY += 10;

      doc.setFontSize(8);
      doc.setFont("helvetica", "bold");
      doc.text("Technical Skills:", margin, leftY);
      leftY += 5;
      doc.setFont("helvetica", "normal");

      const competencyData = filteredData["Competency Coding Details"];
      if (Array.isArray(competencyData) && competencyData.length > 0 && competencyData[0]?.present_competency) {
        const skills = competencyData[0].present_competency.split(',').slice(0, 6);
        skills.forEach(skill => {
          doc.text(`• ${skill.trim()}`, margin, leftY);
          leftY += 4;
        });
      } else {
        doc.text("• Problem Solving", margin, leftY);
        leftY += 4;
        doc.text("• Programming", margin, leftY);
        leftY += 4;
        doc.text("• Data Analysis", margin, leftY);
        leftY += 8;
      }

      doc.setFont("helvetica", "bold");
      doc.text("Soft Skills:", margin, leftY);
      leftY += 5;
      doc.setFont("helvetica", "normal");
      doc.text("• Communication", margin, leftY);
      leftY += 4;
      doc.text("• Team Work", margin, leftY);
      leftY += 4;
      doc.text("• Leadership", margin, leftY);
      leftY += 8;

      // LANGUAGES Section
      if (leftY < pageHeight - 40) {
        doc.setFontSize(14);
        doc.setFont("helvetica", "bold");
        doc.text("LANGUAGES", margin, leftY);
        doc.line(margin, leftY + 2, leftColumnWidth - margin, leftY + 2);
        leftY += 10;

        doc.setFontSize(8);
        doc.setFont("helvetica", "normal");
        doc.text("• English (Fluent)", margin, leftY);
        leftY += 5;
        doc.text("• Tamil (Native)", margin, leftY);
      }

      // ===== RIGHT COLUMN =====

      // Name and Designation Header
      doc.setFontSize(24);
      doc.setFont("helvetica", "bold");
      doc.setTextColor(0, 0, 0);
      doc.text(userInfo?.name || "[Your Full Name]", rightColumnStart + 5, rightY);
      rightY += 10;

      doc.setFontSize(11);
      doc.setFont("helvetica", "normal");
      doc.setTextColor(100, 100, 100);
      doc.text((userInfo?.department || "DEPARTMENT").toUpperCase(), rightColumnStart + 5, rightY);

      // Underline under designation
      doc.setDrawColor(0, 0, 0);
      doc.setLineWidth(1);
      doc.line(rightColumnStart + 5, rightY + 2, rightColumnStart + 60, rightY + 2);
      rightY += 15;

      // Career Objective
      doc.setFontSize(12);
      doc.setFont("helvetica", "bold");
      doc.setTextColor(0, 0, 0);
      doc.text("CAREER OBJECTIVE", rightColumnStart + 5, rightY);
      doc.setLineWidth(0.5);
      doc.line(rightColumnStart + 5, rightY + 2, pageWidth - margin, rightY + 2);
      rightY += 8;

      doc.setFontSize(9);
      doc.setFont("helvetica", "normal");
      const objective = `Motivated and enthusiastic ${userInfo?.department || 'Computer Science'} student seeking opportunities to apply academic knowledge in practical settings. Eager to contribute innovative solutions and continuously develop technical and professional skills.`;
      const objLines = doc.splitTextToSize(objective, pageWidth - rightColumnStart - 15);
      doc.text(objLines, rightColumnStart + 5, rightY);
      rightY += objLines.length * 5 + 8;

      // Get selected sections for right column
      const sectionsOrder = Object.keys(selectedSections).filter(
        (key) => selectedSections[key] && key !== "Student Details" && key !== "Education"
      );

      doc.setTextColor(0, 0, 0);

      sectionsOrder.forEach((sectionKey) => {
        const data = filteredData[sectionKey] || [];
        if (!Array.isArray(data) || data.length === 0) return;

        if (rightY > pageHeight - 40) {
          doc.addPage();

          // Redraw left sidebar on new page
          doc.setFillColor(230, 230, 230);
          doc.rect(0, 0, leftColumnWidth, pageHeight, 'F');
          doc.setDrawColor(100, 100, 100);
          doc.setLineWidth(0.5);
          doc.line(leftColumnWidth, 0, leftColumnWidth, pageHeight);

          rightY = 20;
        }

        // Section Header
        doc.setFontSize(12);
        doc.setFont("helvetica", "bold");
        doc.text(sectionKey.toUpperCase(), rightColumnStart + 5, rightY);
        doc.setLineWidth(0.5);
        doc.line(rightColumnStart + 5, rightY + 2, pageWidth - margin, rightY + 2);
        rightY += 8;

        doc.setFontSize(9);
        doc.setFont("helvetica", "normal");

        // Render section content
        if (sectionKey === "Internships") {
          data.slice(0, 8).forEach((item, index) => {
            if (rightY > pageHeight - 40) {
              doc.addPage();
              doc.setFillColor(230, 230, 230);
              doc.rect(0, 0, leftColumnWidth, pageHeight, 'F');
              doc.setDrawColor(100, 100, 100);
              doc.setLineWidth(0.5);
              doc.line(leftColumnWidth, 0, leftColumnWidth, pageHeight);
              rightY = 20;
            }

            const company = item.provider_name || item.company_name || 'Company';
            const position = item.description || item.position || 'Position';
            const startDate = item.start_date ? new Date(item.start_date).getFullYear() : '';
            const endDate = item.end_date ? new Date(item.end_date).getFullYear() : 'Present';
            const domain = item.domain || '';

            doc.setFont("helvetica", "bold");
            doc.text(`${index + 1}. ${company}`, rightColumnStart + 5, rightY);
            rightY += 5;
            doc.setFont("helvetica", "normal");
            doc.text(`${position} (${startDate} - ${endDate})`, rightColumnStart + 5, rightY);
            rightY += 4;
            if (domain) {
              doc.text(`Domain: ${domain}`, rightColumnStart + 5, rightY);
              rightY += 4;
            }
            rightY += 3;
          });
        } else if (sectionKey === "Project Details") {
          data.slice(0, 8).forEach((item, index) => {
            if (rightY > pageHeight - 40) {
              doc.addPage();
              doc.setFillColor(230, 230, 230);
              doc.rect(0, 0, leftColumnWidth, pageHeight, 'F');
              doc.setDrawColor(100, 100, 100);
              doc.setLineWidth(0.5);
              doc.line(leftColumnWidth, 0, leftColumnWidth, pageHeight);
              rightY = 20;
            }

            const title = item.title || 'Project Title';
            const description = item.description || '';
            const techstack = item.techstack || '';

            doc.setFont("helvetica", "bold");
            doc.text(`${index + 1}. ${title}`, rightColumnStart + 5, rightY);
            rightY += 5;
            doc.setFont("helvetica", "normal");
            if (description) {
              const descLines = doc.splitTextToSize(description, pageWidth - rightColumnStart - 15);
              doc.text(descLines, rightColumnStart + 5, rightY);
              rightY += descLines.length * 4 + 2;
            }
            if (techstack) {
              doc.setTextColor(100, 100, 100);
              doc.text(`Tech Stack: ${techstack}`, rightColumnStart + 5, rightY);
              rightY += 4;
              doc.setTextColor(0, 0, 0);
            }
            rightY += 3;
          });
        } else if (sectionKey === "Achievements") {
          data.slice(0, 10).forEach((item, index) => {
            if (rightY > pageHeight - 40) {
              doc.addPage();
              doc.setFillColor(230, 230, 230);
              doc.rect(0, 0, leftColumnWidth, pageHeight, 'F');
              doc.setDrawColor(100, 100, 100);
              doc.setLineWidth(0.5);
              doc.line(leftColumnWidth, 0, leftColumnWidth, pageHeight);
              rightY = 20;
            }

            const achievement = item.achievement_name || item.title || 'Achievement';
            const description = item.description || '';
            const date = item.date_awarded ? new Date(item.date_awarded).getFullYear() : '';

            doc.setFont("helvetica", "bold");
            doc.text(`${index + 1}. ${achievement}`, rightColumnStart + 5, rightY);
            rightY += 5;
            doc.setFont("helvetica", "normal");
            if (description) {
              const descLines = doc.splitTextToSize(description, pageWidth - rightColumnStart - 15);
              doc.text(descLines, rightColumnStart + 5, rightY);
              rightY += descLines.length * 4 + 2;
            }
            if (date) {
              doc.setTextColor(100, 100, 100);
              doc.text(`Date: ${date}`, rightColumnStart + 5, rightY);
              rightY += 4;
              doc.setTextColor(0, 0, 0);
            }
            rightY += 3;
          });
        } else {
          // Render other sections with numbered lists
          data.slice(0, 10).forEach((item, index) => {
            if (rightY > pageHeight - 40) {
              doc.addPage();
              doc.setFillColor(230, 230, 230);
              doc.rect(0, 0, leftColumnWidth, pageHeight, 'F');
              doc.setDrawColor(100, 100, 100);
              doc.setLineWidth(0.5);
              doc.line(leftColumnWidth, 0, leftColumnWidth, pageHeight);
              rightY = 20;
            }

            const values = Object.values(item).filter(v =>
              v !== null &&
              v !== undefined &&
              typeof v !== 'object' &&
              !String(v).includes('blob') &&
              !String(v).includes('link')
            );

            // Format as numbered list without bars, using commas
            const displayText = values.slice(0, 4).join(", ");
            const truncated = displayText.substring(0, 120);
            const textLines = doc.splitTextToSize(`${index + 1}. ${truncated}`, pageWidth - rightColumnStart - 15);
            doc.text(textLines, rightColumnStart + 5, rightY);
            rightY += textLines.length * 5 + 3;
          });
        }

        rightY += 5;
      });

      // Footer
      doc.setFontSize(8);
      doc.setTextColor(128, 128, 128);
      doc.text(`Generated on ${new Date().toLocaleDateString()}`, pageWidth / 2, pageHeight - 10, { align: "center" });

      if (isPreview) {
        setPreviewMode(doc.output("bloburl"));
      } else {
        doc.save(`${userInfo?.name?.replace(/\s+/g, "_") || "Student_Resume"}.pdf`);
      }
    } catch (error) {
      console.error('Error generating PDF:', error);
      alert('An error occurred while generating the PDF. Please try again.');
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen bg-white">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-t-4 border-b-4 border-indigo-600 mx-auto mb-4"></div>
          <p className="text-lg text-gray-700 font-medium">Loading your resume data...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex justify-center items-center h-screen bg-white">
        <div className="text-center bg-white p-8 rounded-2xl shadow-xl max-w-md">
          <div className="text-red-600 text-6xl mb-4">⚠️</div>
          <p className="text-xl font-semibold text-gray-800 mb-2">Error Loading Data</p>
          <p className="text-gray-600 mb-6">{error}</p>
          <button
            onClick={() => window.location.reload()}
            className="px-6 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg hover:from-blue-700 hover:to-purple-700 transition"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  const selectedCount = Object.values(selectedSections).filter(Boolean).length;

  return (
    <div className="min-h-screen bg-white p-6">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-5xl font-bold text-gray-800 mb-6 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            Professional Resume Generator
          </h1>
          <p className="text-gray-600 text-lg">Create your perfect resume with modern two-column layout</p>
        </div>

        <div className="bg-white rounded-2xl shadow-xl p-6 mb-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-bold text-gray-800 flex items-center">
              <Filter className="mr-3 text-indigo-600" />
              Filter Options
            </h2>
            <button
              onClick={() => setShowFilters(!showFilters)}
              className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg transition hover:from-blue-700 hover:to-purple-700"
            >
              {showFilters ? 'Hide' : 'Show'} Filters
              <ChevronDown className={`w-4 h-4 transition-transform ${showFilters ? 'rotate-180' : ''}`} />
            </button>
          </div>

          {showFilters && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    <Calendar className="inline w-4 h-4 mr-1" />
                    Start Date
                  </label>
                  <input
                    type="date"
                    value={dateFilters.startDate}
                    onChange={(e) => setDateFilters({...dateFilters, startDate: e.target.value})}
                    className="w-full p-3 border-2 border-gray-200 rounded-lg focus:border-indigo-500 focus:outline-none transition"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    <Calendar className="inline w-4 h-4 mr-1" />
                    End Date
                  </label>
                  <input
                    type="date"
                    value={dateFilters.endDate}
                    onChange={(e) => setDateFilters({...dateFilters, endDate: e.target.value})}
                    className="w-full p-3 border-2 border-gray-200 rounded-lg focus:border-indigo-500 focus:outline-none transition"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Month</label>
                  <select
                    value={dateFilters.month}
                    onChange={(e) => setDateFilters({...dateFilters, month: e.target.value})}
                    className="w-full p-3 border-2 border-gray-200 rounded-lg focus:border-indigo-500 focus:outline-none transition"
                  >
                    <option value="">All Months</option>
                    {months.map(m => (
                      <option key={m.value} value={m.value}>{m.label}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Year</label>
                  <select
                    value={dateFilters.year}
                    onChange={(e) => setDateFilters({...dateFilters, year: e.target.value})}
                    className="w-full p-3 border-2 border-gray-200 rounded-lg focus:border-indigo-500 focus:outline-none transition"
                  >
                    <option value="">All Years</option>
                    {years.map(y => (
                      <option key={y} value={y}>{y}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="flex gap-3">
                <button
                  onClick={applyFilters}
                  className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg hover:from-blue-700 hover:to-purple-700 transition font-medium"
                >
                  <Search className="w-4 h-4" />
                  Apply Filters
                </button>
                <button
                  onClick={resetFilters}
                  className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-gray-600 to-gray-700 text-white rounded-lg hover:from-gray-700 hover:to-gray-800 transition font-medium"
                >
                  <RotateCcw className="w-4 h-4" />
                  Reset All
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Section Selection */}
        <div className="bg-white rounded-2xl shadow-xl p-8 mb-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-gray-800">
              Select Resume Sections ({selectedCount})
            </h2>
            <span className="text-sm text-gray-500">Student Details is always included</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {activityList.map((activity) => {
              const isSelected = selectedSections[activity.name];
              const isRequired = activity.name === "Student Details";
              const dataCount = Array.isArray(filteredData[activity.name]) ? filteredData[activity.name].length : 0;

              return (
                <button
                  key={activity.name}
                  onClick={() => toggleSection(activity.name)}
                  disabled={isRequired}
                  className={`
                    relative p-4 rounded-xl border-2 transition-all duration-200 text-left
                    ${isSelected
                      ? 'border-indigo-500 bg-indigo-50 shadow-md'
                      : 'border-gray-200 bg-white hover:border-gray-300 hover:shadow-sm'
                    }
                    ${isRequired ? 'opacity-75 cursor-not-allowed' : 'cursor-pointer'}
                  `}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3 flex-1 min-w-0">
                      <span className="text-2xl flex-shrink-0">{activity.icon}</span>
                      <div className="flex-1 min-w-0">
                        <p className={`font-semibold ${isSelected ? 'text-indigo-700' : 'text-gray-700'} truncate`}>
                          {activity.name}
                        </p>
                        <p className="text-xs text-gray-500 mt-1">
                          {dataCount} item{dataCount !== 1 ? 's' : ''}
                        </p>
                      </div>
                    </div>
                    <div className={`
                      w-6 h-6 rounded-full border-2 flex items-center justify-center flex-shrink-0 ml-3
                      ${isSelected ? 'bg-indigo-600 border-indigo-600' : 'border-gray-300'}
                    `}>
                      {isSelected && (
                        <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                        </svg>
                      )}
                    </div>
                  </div>
                  {isRequired && (
                    <span className="absolute top-2 right-2 text-xs bg-indigo-100 text-indigo-700 px-2 py-1 rounded-full font-medium">
                      Required
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <button
            onClick={() => generatePDF(true)}
            className="flex items-center gap-3 px-8 py-4 bg-gradient-to-r from-indigo-600 to-blue-600 text-white rounded-xl shadow-lg hover:shadow-xl hover:scale-105 transition-all duration-200 font-semibold text-lg"
          >
            <Eye className="w-5 h-5" />
            Preview Resume
          </button>

          <button
            onClick={() => generatePDF(false)}
            className="flex items-center gap-3 px-8 py-4 bg-gradient-to-r from-green-600 to-emerald-600 text-white rounded-xl shadow-lg hover:shadow-xl hover:scale-105 transition-all duration-200 font-semibold text-lg"
          >
            <Download className="w-5 h-5" />
            Download Resume
          </button>
        </div>

        {/* Info Cards */}
        <div className="mt-6 bg-indigo-50 rounded-2xl p-6 border border-indigo-200">
          <h3 className="text-lg font-bold text-indigo-900 mb-3 flex items-center">
            <FileText className="mr-2 w-5 h-5" />
            Resume Generation Tips
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-indigo-800">
            <div className="flex items-start gap-2">
              <span className="text-indigo-600">✓</span>
              <p>Select relevant sections to highlight your best achievements</p>
            </div>
            <div className="flex items-start gap-2">
              <span className="text-indigo-600">✓</span>
              <p>Use date filters to focus on recent activities</p>
            </div>
            <div className="flex items-start gap-2">
              <span className="text-indigo-600">✓</span>
              <p>Preview before downloading to ensure quality</p>
            </div>
            <div className="flex items-start gap-2">
              <span className="text-indigo-600">✓</span>
              <p>Professional two-column layout optimized for ATS systems</p>
            </div>
          </div>
        </div>
      </div>

      {/* PDF Preview Modal */}
      {previewMode && (
        <div
          className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4"
          onClick={() => setPreviewMode(false)}
        >
          <div 
            className="bg-white rounded-2xl max-w-6xl w-full h-[90vh] flex flex-col shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-6 border-b flex justify-between items-center bg-gradient-to-r from-indigo-50 to-blue-50">
              <div>
                <h3 className="text-2xl font-bold text-gray-800">Resume Preview</h3>
                <p className="text-sm text-gray-600 mt-1">Review your professional resume</p>
              </div>
              <button
                onClick={() => setPreviewMode(false)}
                className="text-gray-500 hover:text-gray-700 transition-colors p-2 hover:bg-gray-100 rounded-lg"
              >
                <X className="w-6 h-6" />
              </button>
            </div>
            <iframe 
              src={previewMode} 
              className="flex-1 w-full border-0" 
              title="Resume Preview"
            />
            <div className="p-4 border-t bg-gray-50 flex justify-end gap-3">
              <button
                onClick={() => setPreviewMode(false)}
                className="px-6 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition font-medium"
              >
                Close Preview
              </button>
              <button
                onClick={() => {
                  setPreviewMode(false);
                  generatePDF(false);
                }}
                className="flex items-center gap-2 px-6 py-2 bg-gradient-to-r from-green-600 to-emerald-600 text-white rounded-lg hover:shadow-lg transition font-medium"
              >
                <Download className="w-4 h-4" />
                Download Now
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default EnhancedResumeGenerator;